# MentalhealthAPP
This is Mental Fitness Tracker App Its Front End is Made by HTML,CSS,JS While we had used Flask in its BackEnd And Random Forest Regression To Predict The Model
